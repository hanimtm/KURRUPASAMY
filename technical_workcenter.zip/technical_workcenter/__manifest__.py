# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'KP Technical Task',
    'version': '3.4',
    'category': 'Manufacturing/Manufacturing',
    'description': """
    My Technical Task
    ==============================================
    1) I have added a field which we can add users and users can see only his records in this model
    2) Allow user to add employee name in below time tracking notebook page
    3) create new notebook page and did Balance Qty value calculation
    4) fixed the pivot view in Planning by work center

    """,
    'summary': 'Technical Interview task',
    'website': '',
    'depends': ['product', 'stock', 'resource'],
    'data': [
        'views/survey_report_templates.xml',        
        'security/survey_security.xml',
        'security/ir.model.access.csv',
        
    ],
    
    'installable': True,
    'auto_install': False,
    'application': True,