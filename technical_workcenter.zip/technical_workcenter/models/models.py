from odoo import fields, models,api, _


class Workoredr_task(models.Model):
    _inherit = 'mrp.workorder', 'mrp.production'


    employee = fields.Many2one('resource_id.name',string="Employee" store=True,)
    date = fields.Date("Date")
    finished_qty = fields.Float("Finished Qty")
    machine_name = fields.Char("Machine Name")
    balance_qty = fields.Float("Balance Qty", compute='_compute_balance_qty')

    @api.depends('production_id','finished_qty')
    def _compute_balance_qty(self):
        for rec in self:
            rec.balance_qty = rec.production_id - rec.finished_qty


class Workcenter_task(models.Model):
    _inherit = 'mrp.workcenter'

    allow_users = fields.Many2one('res.user', "Allow users",related='resource_id.user_id')

